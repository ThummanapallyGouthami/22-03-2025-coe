import streamlit as st
st.title("this is simple app with title")
st.header("this is simple app with header")
st.subheader("this is subheader")
